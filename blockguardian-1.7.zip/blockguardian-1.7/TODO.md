#TODO

- Translations/Localization
- MCPE 0.16 blocks + 1.0 blocks!!!
- new entities, block entities
- new icons
- unit tests
- testing!


#extra:

- multithreading of the individual chunks of each tile, with a thread-pool.
- optimizing the top down rendering with lazy chunk loading (from the right direction, stopping when opaque)

#important

- firebase cleanup (remove config, new key)
- google big query!
