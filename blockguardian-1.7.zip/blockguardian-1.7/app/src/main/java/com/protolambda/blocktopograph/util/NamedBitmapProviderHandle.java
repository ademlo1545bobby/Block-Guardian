package com.protolambda.blocktopograph.util;

import android.support.annotation.NonNull;

public interface NamedBitmapProviderHandle {

    @NonNull
    NamedBitmapProvider getNamedBitmapProvider();

}
